package com.novaai.local

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class ChatMessage(val role: String, val content: String, val time: Long = System.currentTimeMillis())

class ChatStore(context: Context) : SQLiteOpenHelper(context, "nova_chat.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE messages (id INTEGER PRIMARY KEY AUTOINCREMENT, role TEXT NOT NULL, content TEXT NOT NULL, time INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE memories (id INTEGER PRIMARY KEY AUTOINCREMENT, content TEXT NOT NULL, time INTEGER NOT NULL)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    fun addMessage(message: ChatMessage) {
        writableDatabase.insert("messages", null, ContentValues().apply {
            put("role", message.role); put("content", message.content); put("time", message.time)
        })
    }

    fun recentMessages(limit: Int = 12): List<ChatMessage> {
        val out = mutableListOf<ChatMessage>()
        readableDatabase.rawQuery(
            "SELECT role, content, time FROM messages ORDER BY id DESC LIMIT ?",
            arrayOf(limit.toString())
        ).use { c ->
            while (c.moveToNext()) out.add(ChatMessage(c.getString(0), c.getString(1), c.getLong(2)))
        }
        return out.reversed()
    }

    fun allMessages(): List<ChatMessage> {
        val out = mutableListOf<ChatMessage>()
        readableDatabase.rawQuery("SELECT role, content, time FROM messages ORDER BY id ASC", null).use { c ->
            while (c.moveToNext()) out.add(ChatMessage(c.getString(0), c.getString(1), c.getLong(2)))
        }
        return out
    }

    fun clearMessages() { writableDatabase.delete("messages", null, null) }

    fun addMemory(content: String) {
        writableDatabase.insert("memories", null, ContentValues().apply {
            put("content", content); put("time", System.currentTimeMillis())
        })
    }

    fun memories(): List<String> {
        val out = mutableListOf<String>()
        readableDatabase.rawQuery("SELECT content FROM memories ORDER BY id DESC LIMIT 30", null).use { c ->
            while (c.moveToNext()) out.add(c.getString(0))
        }
        return out.reversed()
    }
}
