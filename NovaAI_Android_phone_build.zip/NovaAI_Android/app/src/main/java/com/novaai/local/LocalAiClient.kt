package com.novaai.local

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Talks to llama.cpp's local HTTP server on the SAME phone.
 * Start it in Termux on 127.0.0.1:8080 before using chat.
 */
class LocalAiClient(
    private val endpoint: String = "http://127.0.0.1:8080/completion"
) {
    fun generate(prompt: String, maxTokens: Int = 512): String {
        val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 10_000
            readTimeout = 180_000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
        }
        try {
            val body = JSONObject()
                .put("prompt", prompt)
                .put("n_predict", maxTokens)
                .put("temperature", 0.7)
                .put("stop", org.json.JSONArray(listOf("</s>", "User:", "المستخدم:")))
                .toString()
            connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val stream = if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream
            val response = stream.bufferedReader().use { it.readText() }
            if (connection.responseCode !in 200..299) {
                throw IllegalStateException("الخادم المحلي رجّع ${connection.responseCode}: $response")
            }
            val json = JSONObject(response)
            return json.optString("content").ifBlank {
                json.optJSONObject("completion")?.optString("content").orEmpty()
            }.trim().ifBlank { "ما وصلني حتى جواب من النموذج. جرّب مرة أخرى." }
        } finally {
            connection.disconnect()
        }
    }
}
