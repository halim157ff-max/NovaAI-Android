package com.novaai.local

import android.content.Context
import android.net.Uri
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper

object FileReader {
    fun read(context: Context, uri: Uri): String {
        val name = context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val idx = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (cursor.moveToFirst() && idx >= 0) cursor.getString(idx) else ""
        }.orEmpty()
        val type = context.contentResolver.getType(uri).orEmpty()
        return when {
            type == "application/pdf" || name.endsWith(".pdf", true) -> {
                PDFBoxResourceLoader.init(context)
                context.contentResolver.openInputStream(uri).use { input ->
                    requireNotNull(input) { "ما قدرتش نفتح الملف." }.use { stream ->
                        PDDocument.load(stream).use { doc -> PDFTextStripper().getText(doc) }
                    }
                }
            }
            else -> context.contentResolver.openInputStream(uri).use { input ->
                requireNotNull(input) { "ما قدرتش نفتح الملف." }.bufferedReader().use { it.readText() }
            }
        }.take(20_000)
    }
}
