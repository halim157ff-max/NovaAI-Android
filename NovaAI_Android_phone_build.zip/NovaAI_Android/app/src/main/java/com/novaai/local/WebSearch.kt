package com.novaai.local

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup

data class SearchResult(val title: String, val snippet: String, val url: String)

object WebSearch {
    suspend fun search(query: String): List<SearchResult> = withContext(Dispatchers.IO) {
        val url = "https://html.duckduckgo.com/html/?q=" +
            java.net.URLEncoder.encode(query, "UTF-8")
        val doc = Jsoup.connect(url)
            .userAgent("Mozilla/5.0 (Android) NovaAI/0.1")
            .timeout(12_000)
            .get()
        doc.select(".result").take(5).mapNotNull { result ->
            val link = result.selectFirst(".result__a") ?: return@mapNotNull null
            val href = link.absUrl("href").ifBlank { link.attr("href") }
            val snippet = result.selectFirst(".result__snippet")?.text().orEmpty()
            SearchResult(link.text(), snippet, href)
        }
    }
}
